﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;

namespace ConsoleApp
{
    class Program
    {
        private static readonly string BaseUrl =
            "http://appserver.clipperdata.com:8080/ClipperDataAPI-2/rest/clipperapi/data/";

        // Deserialization settings to convert json snake_case to C# PascalCase
        private static readonly JsonSerializerSettings JsonSerializerSettings = new JsonSerializerSettings
        {
            ContractResolver = new DefaultContractResolver
            {
                NamingStrategy = new SnakeCaseNamingStrategy()
            }
        };

        public static void Main(string[] args)
        {
            AccessWebAPIAsync_HttpClient().Wait();
            //Console.WriteLine("Press enter to continue.");
            //Console.ReadLine();
        }

        private static async Task AccessWebAPIAsync_HttpClient()
        {
            // TODO move credentials to a config file, and exclude it from source control
            using (var handler = BuildHttpRequestHandler("henry_tindal", "htindal887"))
            using (var client = new HttpClient(handler))
            {
                var url = BuildUri(0, 0, "global_crude");

                // For a performance point of view, it is better to work with streams, but a string is OK here.
                // A steam would allow the parsing to start as soon as the data is arriving, contrary to a string where we need to wait for the whole request content in order to build it.
                var content = await client.GetStringAsync(url);
                
                
                //ListGradeDynamic(content);

                //ListGradeTyped(content);

                ShowJsonStructure(content);
            }
        }

        /// <summary>
        /// Parse the json content string as a Response object and displays the list of grade contained in the response.
        /// </summary>
        /// <param name="content"></param>
        private static void ListGradeTyped(string content)
        {
            var response = JsonConvert.DeserializeObject<Response>(content, JsonSerializerSettings);

            foreach (var record in response.Record)
            {
                Console.WriteLine(record.Grade);
            }
        }

        /// <summary>
        /// Parse the content string as a JObject and displays the list of grades contained in the response.
        /// </summary>
        /// <param name="content"></param>
        private static void ListGradeDynamic(string content)
        {
            var json = JObject.Parse(content);

            foreach (var record in json["record"])
            {
                var grade =
                    (JProperty)
                    record.FirstOrDefault(recordProperty => (recordProperty as JProperty)?.Name == "grade");
                
                Console.WriteLine(grade);
            }
        }

        /// <summary>
        /// Show the name of the properties and their JSON type of the JSON content
        /// </summary>
        /// <param name="content"></param>
        private static void ShowJsonStructure(string content) => InternalShowJsonContent(JObject.Parse(content));

        private static void InternalShowJsonContent(JToken json, int nesting = 0)
        {
            foreach (var child in json)
            {
                if (child is JObject || child is JArray)
                {
                    Console.WriteLine(new string('\t', nesting) + $"({child.Type}):");
                    InternalShowJsonContent(child, nesting + 1);
                }

                if (!(child is JProperty)) continue;

                var prop = child as JProperty;
                
                Console.WriteLine(new string('\t', nesting)+$"({prop.Value.Type}): \"{prop.Name}\"");

                if (prop.Value.Type == JTokenType.Array || prop.Value.Type == JTokenType.Object)
                {
                    InternalShowJsonContent(prop.Value, nesting+1);
                }
            }
        }


        private static HttpClientHandler BuildHttpRequestHandler(string username, string password) => new HttpClientHandler {Credentials = new NetworkCredential(username, password)};

        private static Uri BuildUri(int datenum, int statnum, string type)
        {
            var query = $"datenum={datenum}&statnum={statnum}&type={type}";
            return new UriBuilder(BaseUrl) {Query = query}.Uri;
        }
    }

    public class Response
    {
        public string RequestStatus { get; set; }
        public ICollection<Record> Record { get; set; }

        public Response()
        {
            Record = new List<Record>();
        }
    }

    public class Record
    {
        public string Grade { get; set; }
    }

}
